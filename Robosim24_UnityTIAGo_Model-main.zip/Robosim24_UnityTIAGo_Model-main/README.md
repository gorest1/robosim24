To Solve an importing urdf import error, added the arms, head and etc to a folder called meshes
